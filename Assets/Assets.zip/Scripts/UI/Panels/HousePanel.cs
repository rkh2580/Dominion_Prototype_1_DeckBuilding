// =============================================================================
// HousePanel.cs
// ��(House) �ý��� �ð�ȭ �г� (UnitPanel ��ü)
// =============================================================================
// [R8-7 ����] 2026-01-03
// - RelocatePopup.OnRelocateCompleted �̺�Ʈ ���� �߰�
// [R9 ����] 2026-01-04
// - ScrollView ������� ���� (������ ���� ����)
// - ���� ��ũ�ѷ� ��� �� ���� ����
// =============================================================================
//
// [Unity ���� ���̵� - ScrollView ����]
// 
// HousePanel (�� ��ũ��Ʈ)
// ������ ScrollRect ������Ʈ
//     ������ Viewport (Mask ������Ʈ)
//     ��   ������ Container (Content, Horizontal Layout Group)
//     ��       ������ HouseCard��...
//     ������ Scrollbar Horizontal (����)
//
// 1. HousePanel�� ScrollRect ������Ʈ �߰�:
//    - Horizontal: ON
//    - Vertical: OFF
//    - Movement Type: Elastic
//    - Viewport: Viewport ������Ʈ
//    - Content: Container ������Ʈ
//
// 2. Viewport ����:
//    - Mask ������Ʈ �߰�
//    - RectTransform: ���ϴ� ǥ�� ���� ũ��
//
// 3. Container�� Horizontal Layout Group �߰�:
//    - Child Alignment: Middle Left
//    - Spacing: 15
//    - Child Force Expand: Width OFF, Height ON
//
// 4. Container�� Content Size Fitter �߰�:
//    - Horizontal Fit: Preferred Size
//    - Vertical Fit: Unconstrained (�Ǵ� Preferred Size)
//
// =============================================================================

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DeckBuildingEconomy.Core;
using DeckBuildingEconomy.Data;

namespace DeckBuildingEconomy.UI
{
    /// <summary>
    /// �� �ý��� �г�
    /// ScrollView�� ���� ��ũ�� ����
    /// </summary>
    public class HousePanel : MonoBehaviour
    {
        [Header("����")]
        [SerializeField] private Transform container;           // Content (Horizontal Layout Group)
        [SerializeField] private GameObject houseCardPrefab;    // HouseCard ������
        [SerializeField] private ScrollRect scrollRect;         // ��ũ�Ѻ�

        [Header("ī�� ����")]
        [SerializeField] private float cardWidth = 220f;        // ī�� �ʺ�
        [SerializeField] private float cardSpacing = 15f;       // ī�� ����

        private List<HouseCard> houseCards = new List<HouseCard>();

        // =====================================================================
        // Unity �����ֱ�
        // =====================================================================

        private void OnEnable()
        {
            // HouseSystem �̺�Ʈ
            HouseSystem.OnHouseCreated += OnHouseChanged;
            HouseSystem.OnHouseRemoved += OnHouseChanged;
            HouseSystem.OnUnitPlaced += OnUnitChanged;
            HouseSystem.OnUnitRemoved += OnUnitRemoved;
            HouseSystem.OnPregnancyStarted += OnHouseStateChanged;
            HouseSystem.OnPregnancyCancelled += OnHouseStateChanged;
            HouseSystem.OnBirth += OnBirth;

            // BreedingSystem �̺�Ʈ
            BreedingSystem.OnBreedingConditionMet += OnHouseStateChanged;
            BreedingSystem.OnChildBorn += OnChildBorn;

            // ��Ÿ �̺�Ʈ
            TurnManager.OnTurnStarted += OnTurnStarted;
            GameManager.OnGameStarted += OnGameStarted;
            UnitSystem.OnUnitLeveledUp += OnUnitLeveledUp;

            // [R8-7] RelocatePopup �̺�Ʈ ����
            RelocatePopup.OnRelocateCompleted += OnRelocateCompleted;
        }

        private void OnDisable()
        {
            HouseSystem.OnHouseCreated -= OnHouseChanged;
            HouseSystem.OnHouseRemoved -= OnHouseChanged;
            HouseSystem.OnUnitPlaced -= OnUnitChanged;
            HouseSystem.OnUnitRemoved -= OnUnitRemoved;
            HouseSystem.OnPregnancyStarted -= OnHouseStateChanged;
            HouseSystem.OnPregnancyCancelled -= OnHouseStateChanged;
            HouseSystem.OnBirth -= OnBirth;

            BreedingSystem.OnBreedingConditionMet -= OnHouseStateChanged;
            BreedingSystem.OnChildBorn -= OnChildBorn;

            TurnManager.OnTurnStarted -= OnTurnStarted;
            GameManager.OnGameStarted -= OnGameStarted;
            UnitSystem.OnUnitLeveledUp -= OnUnitLeveledUp;

            // [R8-7] RelocatePopup �̺�Ʈ ���� ����
            RelocatePopup.OnRelocateCompleted -= OnRelocateCompleted;
        }

        private void Start()
        {
            RefreshAll();
        }

        // =====================================================================
        // �̺�Ʈ �ڵ鷯
        // =====================================================================

        private void OnHouseChanged(HouseInstance house) => RefreshAll();
        private void OnUnitChanged(HouseInstance house, UnitInstance unit, HouseSlotType slot) => RefreshHouse(house.houseId);
        private void OnUnitRemoved(HouseInstance house, UnitInstance unit) => RefreshHouse(house.houseId);
        private void OnHouseStateChanged(HouseInstance house) => RefreshHouse(house.houseId);
        private void OnBirth(HouseInstance house, UnitInstance child) => RefreshHouse(house.houseId);
        private void OnChildBorn(HouseInstance house, UnitInstance a, UnitInstance b, UnitInstance child) => RefreshHouse(house.houseId);
        private void OnTurnStarted(int turn) => RefreshAll();
        private void OnGameStarted() => RefreshAll();
        private void OnUnitLeveledUp(UnitInstance unit, int level, CardInstance card)
        {
            if (!string.IsNullOrEmpty(unit.houseId))
                RefreshHouse(unit.houseId);
        }

        /// <summary>
        /// [R8-7] ���ġ �Ϸ� �� ��ü ����
        /// </summary>
        private void OnRelocateCompleted(UnitInstance unit, HouseInstance house, HouseSlotType slot)
        {
            Debug.Log($"[HousePanel] ���ġ �Ϸ� ����: {unit.unitName} �� {house.houseName}");
            RefreshAll();
        }

        // =====================================================================
        // UI ����
        // =====================================================================

        /// <summary>
        /// ��ü �� ��� ����
        /// </summary>
        public void RefreshAll()
        {
            if (container == null || houseCardPrefab == null) return;

            var state = GameManager.Instance?.State;
            if (state == null) return;

            // ���� ī�� ����
            foreach (var card in houseCards)
            {
                if (card != null) Destroy(card.gameObject);
            }
            houseCards.Clear();

            // ��� �� ���� (�ִ� 12��)
            int count = 0;
            foreach (var house in state.houses)
            {
                if (count >= GameConfig.MaxHouses) break;

                var obj = Instantiate(houseCardPrefab, container);
                var card = obj.GetComponent<HouseCard>();
                if (card != null)
                {
                    card.Bind(house);
                    houseCards.Add(card);
                }
                count++;
            }

            // Content ũ�� ���� (��ũ�ѿ�)
            UpdateContentSize();

            Debug.Log($"[HousePanel] �� {houseCards.Count}�� ǥ��");
        }

        /// <summary>
        /// ���� �� ����
        /// </summary>
        public void RefreshHouse(string houseId)
        {
            var card = houseCards.Find(c => c.BoundHouse?.houseId == houseId);
            card?.Refresh();
        }

        // =====================================================================
        // Content ũ�� ���� (��ũ�ѿ�)
        // =====================================================================

        /// <summary>
        /// Container(Content)�� ũ�⸦ ī�� ������ �°� ����
        /// </summary>
        private void UpdateContentSize()
        {
            if (container == null) return;

            var rectTransform = container.GetComponent<RectTransform>();
            if (rectTransform == null) return;

            int count = houseCards.Count;
            if (count == 0) return;

            // �� �ʺ� = (ī�� �ʺ� �� ����) + (���� �� (����-1)) + ���� �е�
            float totalWidth = (cardWidth * count) + (cardSpacing * (count - 1)) + 20f;

            // Content ũ�� ����
            rectTransform.sizeDelta = new Vector2(totalWidth, rectTransform.sizeDelta.y);
        }

        // =====================================================================
        // ��ũ�� ����
        // =====================================================================

        /// <summary>
        /// ��ũ���� �� �������� �̵�
        /// </summary>
        public void ScrollToStart()
        {
            if (scrollRect != null)
            {
                scrollRect.horizontalNormalizedPosition = 0f;
            }
        }

        /// <summary>
        /// ��ũ���� �� ���������� �̵�
        /// </summary>
        public void ScrollToEnd()
        {
            if (scrollRect != null)
            {
                scrollRect.horizontalNormalizedPosition = 1f;
            }
        }

        /// <summary>
        /// Ư�� ������ ��ũ��
        /// </summary>
        public void ScrollToHouse(string houseId)
        {
            if (scrollRect == null) return;

            int index = houseCards.FindIndex(c => c.BoundHouse?.houseId == houseId);
            if (index < 0) return;

            int count = houseCards.Count;
            if (count <= 1) return;

            float normalizedPos = (float)index / (count - 1);
            scrollRect.horizontalNormalizedPosition = normalizedPos;
        }

        // =====================================================================
        // �ܺ� ����
        // =====================================================================

        /// <summary>
        /// Ư�� �� ī�� ã��
        /// </summary>
        public HouseCard GetHouseCard(string houseId)
        {
            return houseCards.Find(c => c.BoundHouse?.houseId == houseId);
        }

        /// <summary>
        /// ��� �� ī��
        /// </summary>
        public IReadOnlyList<HouseCard> AllHouseCards => houseCards.AsReadOnly();
    }
}